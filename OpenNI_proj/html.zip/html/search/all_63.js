var searchData=
[
  ['clear',['clear',['../struct_finger_list.html#a36c240233d219490d9a0adae746e66ac',1,'FingerList']]],
  ['curve',['curve',['../struct_finger_frame.html#acc699ff3b95eaab70704715ca5804b28',1,'FingerFrame']]]
];
