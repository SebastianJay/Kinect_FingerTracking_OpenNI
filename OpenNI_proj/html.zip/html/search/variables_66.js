var searchData=
[
  ['fingers',['fingers',['../struct_finger_frame.html#a412bbad870a97cc52c481d9f04658de4',1,'FingerFrame']]],
  ['framenum',['frameNum',['../struct_finger_frame.html#ace5440975f3cfa5c5fa5b1dd0197c938',1,'FingerFrame']]]
];
