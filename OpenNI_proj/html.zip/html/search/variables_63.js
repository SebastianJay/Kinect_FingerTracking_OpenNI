var searchData=
[
  ['curve',['curve',['../struct_finger_frame.html#acc699ff3b95eaab70704715ca5804b28',1,'FingerFrame']]]
];
