var searchData=
[
  ['vertices',['vertices',['../struct_finger_frame.html#a32cea32f95fcbb87c26a9e99e1e30a4b',1,'FingerFrame']]]
];
