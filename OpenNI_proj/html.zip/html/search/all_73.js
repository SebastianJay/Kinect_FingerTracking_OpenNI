var searchData=
[
  ['setmaxdepth',['setMaxDepth',['../class_finger_tracker.html#a76e02f8bbbddaa77e2bf42de0f63e5ad',1,'FingerTracker']]],
  ['setmaxvalues',['setMaxValues',['../struct_finger_vector.html#ab8976c18ddd99bcc82f37091f6f86843',1,'FingerVector']]],
  ['setmindepth',['setMinDepth',['../class_finger_tracker.html#a019b3f55e8958ba2444443bb79f7cabd',1,'FingerTracker']]],
  ['setsearchradius',['setSearchRadius',['../class_finger_tracker.html#a16172f3f662050dabac9a910e2b02581',1,'FingerTracker']]],
  ['setthetathreshold',['setThetaThreshold',['../class_finger_tracker.html#adc8af5c0bb9290220b783d63eaa78f92',1,'FingerTracker']]],
  ['size',['size',['../struct_finger_list.html#a0f2e620d7f07679c96921bfc5fd995c5',1,'FingerList']]]
];
