var searchData=
[
  ['avgpos',['avgPos',['../struct_finger_frame.html#a115d1895c7352e9bfa936f5cfead9e7d',1,'FingerFrame']]]
];
