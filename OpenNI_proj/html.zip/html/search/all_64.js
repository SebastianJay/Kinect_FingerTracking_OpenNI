var searchData=
[
  ['deltapos',['deltaPos',['../struct_finger_frame.html#a81968f4c07d9d075cc6af8685c70b9dd',1,'FingerFrame']]]
];
